$.timer = function(time,func,callback){
    var a = {timer:setTimeout(func,time),callback:null}
    if(typeof(callback) == 'function'){a.callback = callback;}
    return a;
};

$.clearTimer = function(a){
    clearTimeout(a.timer);
    if(typeof(a.callback) == 'function'){a.callback();};
    return this;
};
isChrome = function() {
	return Boolean(window.chrome);
}

var origSrc;
var browserV;
var slowloader;
var topic;

$(document).ready(function () {

	function openTop(){
		$('#top_map').css('opacity','1');
		$('a#home_link').addClass('prevent');
		$('header').animate({
		'marginTop': '0'
		},500);
		$('a.closeHeader').fadeIn();

		if(browserV == "ieold") {
			$('#top_info, #top_map, #top_hours').show();
			$('#header_mark').show();
			$('#header_mark').animate({
			'height': '185px'
			},500);
			$('#top_fixed').hide();
		} else {
			$('#top_info, #top_map, #top_hours').fadeIn(500);
			$('#header_mark').animate({
			'opacity': '.8',
			'height': '185px'
			},500);
			$('#top_fixed').fadeOut(500);
		}
	}

	function closeTop(){
		$('header').animate({
		'marginTop': '-144px'
		},500);
		$('a.closeHeader').fadeOut();
		if(browserV == "ieold") {
			$('#top_info, #top_map, #top_hours').hide();
			$('#header_mark').animate({
				'height': '41px'
			},500, function(){
				$('#header_mark').hide();
			});
			$('#top_fixed').show();
		} else {
			$('#header_mark').animate({
			'opacity': '0',
			'height': '41px'
			},500);
			$('#top_info, #top_map, #top_hours').fadeOut(500);
			$('#top_fixed').fadeIn(500);
		}
		$('a#home_link').removeClass('prevent');
	}

	if($.browser.msie && ($.browser.version.charAt(0) <= 8 || (document.documentMode && document.documentMode == 7))) {
		browserV = "ieold";
		$("#twitter_feed ul").mCustomScrollbar({
			scrollButtons: { enable: false },
			scrollEasing: 'linear'
		});
	} else if(navigator.appVersion.indexOf("Win")!=-1 && isChrome()) {
		browserV = "winchrome";
		$("#twitter_feed ul").mCustomScrollbar({
			scrollButtons: { enable: false },
			scrollEasing: 'linear'
		}).css({
			'overflow-y': 'hidden',
			'width': '210px',
			'padding-right': 0
		});
	} else if($.browser.mozilla){
		browserV = "firefox";
		if(navigator.appVersion.indexOf("Win")==-1)
			$('ul#home_nav li ul.drop_04 p a').css({'background-position': 'right 4px'})
		
		$("#twitter_feed ul").mCustomScrollbar({
			scrollButtons: { enable: false },
			scrollEasing: 'linear'
		}).css({
			'overflow-y': 'hidden',
			'width': '210px',
			'padding-right': 0
		});
		
		if(navigator.appVersion.indexOf("Win")!=-1)
			browserV = "winfox";
	} else if(navigator.userAgent.toLowerCase().match(/(iphone|ipod|ipad)/)) {
		browserV = "iOS"
	}
	
	origSrc = $('iframe#cal_big').attr('src');
	
	$('.modal').click(function(event){
		$('#basic-modal-content').modal();
			event.preventDefault;
			return false;
	});
	
	$('.calpop').click(function(event){

		$('#calendar-overlay').show();
		$('iframe#cal_big').css('visibility','hidden').attr('src',origSrc);
		
		$('#calendar-wrap').css('top','50px').removeClass('offline');
		$('#calendar-wrap a.modalCloseImg').click(function(){
			$('#calendar-wrap').css('top','-1200px').addClass('offline');
			$('#calendar-overlay').hide();
		});
		
		slowLoader = $.timer(1000,function(){
			$('iframe#cal_big').css('visibility','visible');
		});

		event.preventDefault;
		return false;
	});
	
	$('#social_icons img').hover(
		function(){
			var newsource = $(this).attr('src').replace('_over','');
			$(this).attr('src',newsource);
		},
		function(){
			var newsource = $(this).attr('src').replace('.png','_over.png');
			$(this).attr('src',newsource);
	});
	
	$('#twitter_feed img').hover(
		function(){
			var newsource = $(this).attr('src').replace('_drop','');
			$(this).attr('src',newsource).css('margin','26px 26px 3px 3px');
		},
		function(){
			var newsource = $(this).attr('src').replace('.png','_drop.png');
			$(this).attr('src',newsource).css('margin','25px 25px 4px 4px');
	});
	
	$('#twitter_feed ul li:last-child').addClass('last');
	
	var backpic;
	$('div#footer_icons li p').hover(
		function(){
			backpic = $(this).css('background-image');
			$(this).css('background-image', backpic.replace('.png','_over.png'));
		},
		function(){
			$(this).css('background-image', backpic);
	});
	
	$('#top_nav_right').click(function(){
		openTop();
	});	

	$('#outer_wrapper').click(function(){
		if($('a#home_link').hasClass('prevent')){
			closeTop();
		}
	});
	
	$('a.closeHeader').click(function(){
		closeTop();
	});
	
	$('a#home_link').click(function(event){
		if($(this).hasClass('prevent')){
			event.preventDefault();
		}
	});
	
	$('#home_nav li.top_shelf').hoverIntent(
	function(){
	  $(this).addClass('hover');
	  $(this).children('ul').slideDown();
	},
	function(){
	  if(!$(this).children('li').hasClass('hover')){
		  $(this).removeClass("hover");
		  $(this).children('ul').slideUp();
	  }
	});
});
